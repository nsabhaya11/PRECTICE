//
//  ViewController.m
//  newApp
//
//  Created by MACOS on 9/8/16.
//  Copyright © 2016 surat. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnclick:(id)sender {
    UIAlertController *alt=[UIAlertController alertControllerWithTitle:@"Dialog title" message:@"using first alert" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *act=[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"click ok");
    }];
    
    [alt addAction:act];
    
    
    UIAlertAction *act2=[UIAlertAction actionWithTitle:@"cancel" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"click cancel");
    }];
    
    [alt addAction:act2];
    
    
    [self presentViewController:alt animated:YES completion:nil];
    
    }
@end
