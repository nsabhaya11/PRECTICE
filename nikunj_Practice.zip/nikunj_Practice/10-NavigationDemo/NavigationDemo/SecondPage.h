//
//  SecondPage.h
//  NavigationDemo
//
//  Created by MACOS on 9/29/16.
//  Copyright © 2016 surat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondPage : UIViewController
- (IBAction)btnback:(id)sender;

@end
