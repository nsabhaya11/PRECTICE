//
//  ViewController.h
//  NavigationDemo
//
//  Created by MACOS on 9/29/16.
//  Copyright © 2016 surat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)btnclick:(id)sender;

@end

