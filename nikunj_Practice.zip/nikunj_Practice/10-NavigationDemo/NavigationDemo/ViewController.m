//
//  ViewController.m
//  NavigationDemo
//
//  Created by MACOS on 9/29/16.
//  Copyright © 2016 surat. All rights reserved.
//

#import "ViewController.h"
#import "SecondPage.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnclick:(id)sender {
    SecondPage *pg=[self.storyboard instantiateViewControllerWithIdentifier:@"pageid2"];
    
    [self.navigationController pushViewController:pg animated:YES];
}
@end
