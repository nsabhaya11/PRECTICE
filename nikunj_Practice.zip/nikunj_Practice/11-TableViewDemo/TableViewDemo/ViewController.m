//
//  ViewController.m
//  TableViewDemo
//
//  Created by MACOS on 9/29/16.
//  Copyright © 2016 surat. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    arr=[[NSMutableArray alloc] initWithObjects:@"Asp.Net",@"Adv.Java",@"Android",@"iPhone", nil];
    
    img=[[NSMutableArray alloc] initWithObjects:@"1.jpg",@"1.jpg",@"1.jpg",@"1.jpg", nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arr count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    cell.textLabel.text=[arr objectAtIndex:indexPath.row];
    cell.imageView.image=[UIImage imageNamed:[img objectAtIndex:indexPath.row]];
    
    return cell;
    
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if (section==0) {
        return @"First Table";
    } else {
        return @"Second Table";
    }
}

-(NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section
{
    if (section==0) {
        return @"First Table";
    } else {
        return @"Second Table";
    }
}


@end
