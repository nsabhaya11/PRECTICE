//
//  AppDelegate.h
//  TableViewCustomDemo
//
//  Created by MACOS on 10/3/16.
//  Copyright © 2016 tops. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

