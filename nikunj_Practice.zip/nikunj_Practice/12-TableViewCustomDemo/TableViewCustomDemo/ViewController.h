//
//  ViewController.h
//  TableViewCustomDemo
//
//  Created by MACOS on 10/3/16.
//  Copyright © 2016 tops. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray *arr,*img;
}

@end

