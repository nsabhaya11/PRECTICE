//
//  ViewController.m
//  TableViewCustomDemo
//
//  Created by MACOS on 10/3/16.
//  Copyright © 2016 tops. All rights reserved.
//

#import "ViewController.h"
#import "custcell.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    arr=[[NSMutableArray alloc] initWithObjects:@"Android",@"Asp.Net",@"Java",@"iPhone", nil];
    
    img=[[NSMutableArray alloc] initWithObjects:@"comments.png",@"comments.png",@"comments.png",@"comments.png", nil];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arr count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    custcell *cust=[tableView dequeueReusableCellWithIdentifier:@"cell1"];
    cust.lbl.text=[arr objectAtIndex:indexPath.row];
    cust.imgv.image=[UIImage imageNamed:[img objectAtIndex:indexPath.row]];
    
    [cust.btn addTarget:self action:@selector(newclick:) forControlEvents:UIControlEventTouchUpInside];
    
    cust.accessoryType=UITableViewCellAccessoryDetailButton;
    
    return cust;
}
	
-(void)newclick:(UIButton *)bt
{
    UIAlertController *alt=[UIAlertController alertControllerWithTitle:@"Show Msg" message:@"Clicked from cell" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *act=[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    
    [alt addAction:act];
    
    [self presentViewController:alt animated:YES completion:nil];
   // bt.backgroundColor=[UIColor yellowColor];
}


-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [arr removeObjectAtIndex:indexPath.row];
    [img removeObjectAtIndex:indexPath.row];
    
    [tableView reloadData];
}

@end
