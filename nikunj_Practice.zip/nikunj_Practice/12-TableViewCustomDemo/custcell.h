//
//  custcell.h
//  TableViewCustomDemo
//
//  Created by MACOS on 10/3/16.
//  Copyright © 2016 tops. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface custcell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lbl;
@property (weak, nonatomic) IBOutlet UIImageView *imgv;
- (IBAction)btnclick:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btn;

@end
