//
//  custcell.m
//  TableViewCustomDemo
//
//  Created by MACOS on 10/3/16.
//  Copyright © 2016 tops. All rights reserved.
//

#import "custcell.h"

@implementation custcell

- (IBAction)btnclick:(id)sender {
    UIAlertController *alt=[UIAlertController alertControllerWithTitle:@"Show Msg" message:@"Clicked from cell" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *act=[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    
    [alt addAction:act];
    
}
@end
