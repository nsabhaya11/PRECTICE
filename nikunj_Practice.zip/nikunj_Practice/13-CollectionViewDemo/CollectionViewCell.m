//
//  CollectionViewCell.m
//  CollectionViewDemo
//
//  Created by MACOS on 04/10/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import "CollectionViewCell.h"

@implementation CollectionViewCell

@end
