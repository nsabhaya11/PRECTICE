//
//  ViewController.m
//  CollectionViewDemo
//
//  Created by MACOS on 04/10/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import "ViewController.h"
#import "mycell.h"
#import "NextView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    img=[[NSMutableArray alloc] initWithObjects:@"1.jpg",@"2.jpg",@"3.jpg",@"4.jpg",@"climb.jpg", nil];
    
    arr=[[NSMutableArray alloc] initWithObjects:@"a",@"b",@"c",@"d",@"e", nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [img count];
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    mycell *myc=[collectionView dequeueReusableCellWithReuseIdentifier:@"cell1" forIndexPath:indexPath];
    
    myc.imgv.image=[UIImage imageNamed:[img objectAtIndex:indexPath.row]];
    myc.lbl.text=[arr objectAtIndex:indexPath.row];
    [myc.btn addTarget:self action:@selector(myclick:) forControlEvents:UIControlEventTouchUpInside];
    
    myc.btn.tag=indexPath.row;
    
    return myc;
}

-(void)myclick:(UIButton *)senderbtn
{
    UIAlertController *alt=[UIAlertController alertControllerWithTitle:@"My Title" message:[arr objectAtIndex:senderbtn.tag] preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *act=[UIAlertAction actionWithTitle:@"ok" style:UIAlertActionStyleDefault handler:nil];
    
    [alt addAction:act];
    [self presentViewController:alt animated:YES completion:nil];
    
}


-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPathcoll
{
    NextView *nv=[self.storyboard instantiateViewControllerWithIdentifier:@"newid"];
    
    nv.simg= [img objectAtIndex:indexPathcoll.row];
    nv.sname=[arr objectAtIndex:indexPathcoll.row];
    
    [self.navigationController pushViewController:nv animated:YES];
    
    
    
}



@end
