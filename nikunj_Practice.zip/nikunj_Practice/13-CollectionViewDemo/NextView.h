//
//  NextView.h
//  CollectionViewDemo
//
//  Created by MACOS on 05/10/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NextView : UIViewController

@property (strong, nonatomic) IBOutlet UIImageView *imgv;
@property (strong, nonatomic) IBOutlet UILabel *lbl;
@property(retain,nonatomic)NSString *simg;
@property(retain,nonatomic)NSString *sname;

@end
