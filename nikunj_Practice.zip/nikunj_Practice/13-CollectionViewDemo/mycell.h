//
//  mycell.h
//  CollectionViewDemo
//
//  Created by MACOS on 04/10/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface mycell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIImageView *imgv;
@property (weak, nonatomic) IBOutlet UILabel *lbl;
- (IBAction)btnclick:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btn;

@end
