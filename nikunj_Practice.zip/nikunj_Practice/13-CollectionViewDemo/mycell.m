//
//  mycell.m
//  CollectionViewDemo
//
//  Created by MACOS on 04/10/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import "mycell.h"

@implementation mycell

- (IBAction)btnclick:(id)sender {
}
@end
