//
//  ViewController.h
//  ValidationDemo
//
//  Created by MACOS on 13/10/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TextFieldValidator.h"

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet TextFieldValidator *txtname;
@property (weak, nonatomic) IBOutlet TextFieldValidator *txtpass;
@property (weak, nonatomic) IBOutlet TextFieldValidator *txtemail;
@property (weak, nonatomic) IBOutlet TextFieldValidator *txtmob;
- (IBAction)btnclick:(id)sender;

@end

