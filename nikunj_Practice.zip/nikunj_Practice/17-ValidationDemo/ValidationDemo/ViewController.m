//
//  ViewController.m
//  ValidationDemo
//
//  Created by MACOS on 13/10/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import "ViewController.h"

#define REGEX_USER_NAME_LIMIT @"^.{3,10}$"
#define REGEX_USER_NAME @"[A-Za-z0-9]{3,10}"
#define REGEX_EMAIL @"[A-Z0-9a-z._%+-]{3,}+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
#define REGEX_PASSWORD_LIMIT @"^.{6,20}$"
#define REGEX_PASSWORD @"[A-Za-z0-9]{6,20}"
#define REGEX_PHONE_DEFAULT @"[0-9]{10,10}"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [_txtname addRegx:REGEX_USER_NAME withMsg:@"Invalid username"];
    _txtname.presentInView=self.view;
    [_txtpass addRegx:REGEX_PASSWORD withMsg:@"Invalid Password"];
    _txtpass.presentInView=self.view;
    [_txtemail addRegx:REGEX_EMAIL withMsg:@"Invalid Email"];
    _txtemail.presentInView=self.view;
    [_txtmob addRegx:REGEX_PHONE_DEFAULT withMsg:@"Invalid Mobile"];
    _txtmob.presentInView=self.view;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnclick:(id)sender {
    if ([_txtname validate]) {
        //
    }
}
@end
