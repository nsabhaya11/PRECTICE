//
//  main.m
//  ValidationDemo
//
//  Created by MACOS on 13/10/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
