//
//  AppDelegate.h
//  GestureControlsDemo
//
//  Created by MACOS on 14/10/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

