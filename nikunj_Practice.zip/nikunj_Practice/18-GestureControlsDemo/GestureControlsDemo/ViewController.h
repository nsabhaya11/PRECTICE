//
//  ViewController.h
//  GestureControlsDemo
//
//  Created by MACOS on 14/10/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lbl1;
@property (weak, nonatomic) IBOutlet UIImageView *img;

@end

