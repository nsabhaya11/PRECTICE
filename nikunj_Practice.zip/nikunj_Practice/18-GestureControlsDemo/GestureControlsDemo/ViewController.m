//
//  ViewController.m
//  GestureControlsDemo
//
//  Created by MACOS on 14/10/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //tap
    UITapGestureRecognizer *tap=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(fn_tap)];
    
    tap.numberOfTapsRequired=1;
    _lbl1.userInteractionEnabled=YES;
    [_lbl1 addGestureRecognizer:tap];
    
    
    //long press
    UILongPressGestureRecognizer *lp=[[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(setLabel)];
    
    lp.minimumPressDuration=1;
    [_lbl1 addGestureRecognizer:lp];
    
    
    // swip
    UISwipeGestureRecognizer *sw=[[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(setLabel)];
    
    sw.direction=UISwipeGestureRecognizerDirectionLeft;
    [self.view addGestureRecognizer:sw];
    
    
    //rotation
    UIRotationGestureRecognizer *rot=[[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(imgRotate:)];
    
    _img.userInteractionEnabled=YES;
    [self.view addGestureRecognizer:rot];
    
    
    // Pinch
    UIPinchGestureRecognizer *pin=[[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(imgPinch:)];
    
    _img.userInteractionEnabled=YES;
    [self.view addGestureRecognizer:pin];
    
    
    //pan
    
    UIPanGestureRecognizer *pan=[[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(imgPan:)];
    [self.view addGestureRecognizer:pan];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)imgRotate:(UIRotationGestureRecognizer *)rt
{
    self.img.transform=CGAffineTransformRotate(self.img.transform, rt.rotation);
    rt.rotation=0;
}

-(void)imgPinch:(UIPinchGestureRecognizer *)pc
{
    self.img.transform=CGAffineTransformScale(self.img.transform, pc.scale, pc.scale);
}

-(void)imgPan:(UIPanGestureRecognizer *)pn
{
    self.img.center = [pn locationInView:self.view];
}

-(void)setLabel
{
    static int a=0;
    _lbl1.text=[NSString stringWithFormat:@"%d",a];
    a++;
}

-(void)fn_tap
{
    NSLog(@"tap");
}

@end
