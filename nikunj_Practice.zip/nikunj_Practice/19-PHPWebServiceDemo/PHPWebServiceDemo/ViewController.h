//
//  ViewController.h
//  PHPWebServiceDemo
//
//  Created by MACOS on 18/10/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)btnclick:(id)sender;

@end

