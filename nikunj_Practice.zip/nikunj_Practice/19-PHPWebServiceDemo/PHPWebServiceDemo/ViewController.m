//
//  ViewController.m
//  PHPWebServiceDemo
//
//  Created by MACOS on 18/10/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnclick:(id)sender {
    NSURL *url=[NSURL URLWithString:@"http://localhost/Ankit/MyApi.php?f_name=ankit&age=25"];
    
    NSURLRequest *req=[NSURLRequest requestWithURL:url];
    NSURLSession *session=[NSURLSession sharedSession];
    
    NSURLSessionDataTask *task=[session dataTaskWithRequest:req completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
       
        NSString *str=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        
        NSLog(@"%@",str);
        
    }];
    
    [task resume];
}
@end
