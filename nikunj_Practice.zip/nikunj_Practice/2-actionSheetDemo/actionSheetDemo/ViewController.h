//
//  ViewController.h
//  actionSheetDemo
//
//  Created by MACOS on 9/8/16.
//  Copyright © 2016 surat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)btnclick:(id)sender;


@end

