//
//  ViewController.m
//  actionSheetDemo
//
//  Created by MACOS on 9/8/16.
//  Copyright © 2016 surat. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)btnclick:(id)sender {
    UIAlertController *alt=[UIAlertController alertControllerWithTitle:@"ok" message:@"select Option" preferredStyle:UIAlertControllerStyleActionSheet];
 
    UIAlertAction *ok=[UIAlertAction actionWithTitle:@"ok" style:UIAlertControllerStyleAlert handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"ok");
    }];
    
    [alt addAction:ok];
    [self presentViewController:alt animated:YES completion:nil];
    
}
@end
