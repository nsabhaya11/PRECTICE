//
//  ViewController.h
//  segmentControlDemo
//
//  Created by MACOS on 9/10/16.
//  Copyright © 2016 surat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    NSTimer *time;
}
@property (weak, nonatomic) IBOutlet UISegmentedControl *seg;

- (IBAction)segaction:(id)sender;
@property (weak, nonatomic) IBOutlet UISwitch *swt;
- (IBAction)swtaction:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lbl;
@property (weak, nonatomic) IBOutlet UILabel *lbl2;
@property (weak, nonatomic) IBOutlet UISlider *sdr;
- (IBAction)sdraction:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *lbl3;
@property (weak, nonatomic) IBOutlet UIProgressView *prg;

- (IBAction)btnClick:(id)sender;

@property (weak, nonatomic) IBOutlet UIStepper *stp;

@property (weak, nonatomic) IBOutlet UILabel *lbl4;
- (IBAction)stpAction:(id)sender;
@end

