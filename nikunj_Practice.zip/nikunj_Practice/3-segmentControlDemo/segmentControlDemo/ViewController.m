//
//  ViewController.m
//  segmentControlDemo
//
//  Created by MACOS on 9/10/16.
//  Copyright © 2016 surat. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)segaction:(id)sender {
    if (_seg.selectedSegmentIndex==0) {
        self.view.backgroundColor=[UIColor redColor];
    }
    else if (_seg.selectedSegmentIndex==1)
    {
        self.view.backgroundColor=[UIColor greenColor];
    }
}


- (IBAction)swtaction:(id)sender {
    
    if (_swt.on) {
        _lbl.text=@"ON";
    }
    else if (_swt.on==false)
    {
        _lbl.text=@"Off";
    }
    
}
- (IBAction)sdraction:(id)sender {
    
    _lbl2.text=[NSString stringWithFormat:@"%d",(int)_sdr.value];
}

- (IBAction)btnClick:(id)sender {
    time=[NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(callforProgress) userInfo:nil repeats:YES];
}

-(void) callforProgress
{
    _prg.progress+=0.10;
}

- (IBAction)stpAction:(id)sender {
    _lbl4.text=[NSString stringWithFormat:@"%d",(int)_stp.value];
}
@end
