//
//  ViewController.m
//  activityIndicator
//
//  Created by MACOS on 9/23/16.
//  Copyright © 2016 surat. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [_act setHidden:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnStart:(id)sender {
    [_act setHidden:NO];
    [_act startAnimating];
    
}

- (IBAction)btnEnd:(id)sender {
    [_act stopAnimating];
    [_act setHidden:YES];
}
@end
