//
//  ViewController.h
//  datePicker
//
//  Created by MACOS on 9/23/16.
//  Copyright © 2016 surat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UIDatePicker *dtp;
@property (weak, nonatomic) IBOutlet UITextField *txt;
- (IBAction)dtpChange:(id)sender;

@end

