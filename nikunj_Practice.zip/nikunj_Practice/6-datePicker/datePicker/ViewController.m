//
//  ViewController.m
//  datePicker
//
//  Created by MACOS on 9/23/16.
//  Copyright © 2016 surat. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _dtp.hidden=YES;
    
    NSDate *dt=[NSDate date];
    NSDateFormatter *frm=[[NSDateFormatter alloc] init];
    
    [frm setDateFormat:@"dd-MM-yyyy"];
    
    _txt.text=[frm stringFromDate:dt];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    _dtp.hidden=NO;
    return NO;
}


- (IBAction)dtpChange:(id)sender {
    NSDate *dt1=[_dtp date];
    NSDateFormatter *frm1=[[NSDateFormatter alloc] init];
    
    [frm1 setDateFormat:@"dd-MM-yyyy"];
    
    _txt.text=[frm1 stringFromDate:dt1];
}
@end
