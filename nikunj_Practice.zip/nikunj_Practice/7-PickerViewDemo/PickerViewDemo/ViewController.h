//
//  ViewController.h
//  PickerViewDemo
//
//  Created by MACOS on 9/27/16.
//  Copyright © 2016 surat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<UIPickerViewDataSource,UIPickerViewDelegate>
{
    NSArray *ary,*ary2;
}

@property (weak, nonatomic) IBOutlet UITextField *txt;

@end

