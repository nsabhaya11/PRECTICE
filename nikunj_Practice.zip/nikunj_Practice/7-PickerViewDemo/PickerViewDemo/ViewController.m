//
//  ViewController.m
//  PickerViewDemo
//
//  Created by MACOS on 9/27/16.
//  Copyright © 2016 surat. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    ary=[[NSArray alloc] initWithObjects:@"Mobile",@"Laptop",@"Tablet",@"Desktop", nil];
    ary2=[[NSArray alloc] initWithObjects:@"iPhone",@"Asp.net",@"Java",@"Android", nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 2;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (component==0) {
        return ary.count;
    } else {
        return ary2.count;
    }
    
}

-(NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (component==0) {
        return [ary objectAtIndex:row];
    } else {
        return [ary2 objectAtIndex:row];
    }
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    if (component==0) {
        _txt.text=[ary objectAtIndex:row];
    } else {
        _txt.text=[ary2 objectAtIndex:row];
    }
}

@end
