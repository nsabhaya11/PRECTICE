//
//  AppDelegate.h
//  WebViewDemo
//
//  Created by MACOS on 9/27/16.
//  Copyright © 2016 surat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

