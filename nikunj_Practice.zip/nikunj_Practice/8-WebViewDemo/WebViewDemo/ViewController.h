//
//  ViewController.h
//  WebViewDemo
//
//  Created by MACOS on 9/27/16.
//  Copyright © 2016 surat. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    
}

@property (weak, nonatomic) IBOutlet UIWebView *web;

@end

