//
//  ViewController.h
//  ScrollViewDemo
//
//  Created by MACOS on 28/09/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIScrollView *scrl;
@property (weak, nonatomic) IBOutlet UIImageView *imgv;

@end

