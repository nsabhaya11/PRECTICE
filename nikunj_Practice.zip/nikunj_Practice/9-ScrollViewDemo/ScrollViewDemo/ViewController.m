//
//  ViewController.m
//  ScrollViewDemo
//
//  Created by MACOS on 28/09/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _scrl.contentSize=CGSizeMake(_imgv.frame.size.width, _imgv.frame.size.height);
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
