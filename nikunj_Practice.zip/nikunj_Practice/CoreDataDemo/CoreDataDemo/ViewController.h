//
//  ViewController.h
//  CoreDataDemo
//
//  Created by MACOS on 24/11/16.
//  Copyright © 2016 infinity. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CoreData/CoreData.h"
#import "AppDelegate.h"

@interface ViewController : UIViewController
{
    AppDelegate *appdelegate;
}
@property (weak, nonatomic) IBOutlet UITextField *txtid;
@property (weak, nonatomic) IBOutlet UITextField *txtfname;
@property (weak, nonatomic) IBOutlet UITextField *txtage;

- (IBAction)btninsert:(id)sender;
- (IBAction)btnupdate:(id)sender;
- (IBAction)btndelete:(id)sender;
- (IBAction)btnfind:(id)sender;

@property(strong,nonatomic)NSManagedObjectContext *context;
@property (strong,nonatomic)NSManagedObject *object;

@end

