//
//  ViewController.m
//  CoreDataDemo
//
//  Created by MACOS on 24/11/16.
//  Copyright © 2016 infinity. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    appdelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    
    self.context = appdelegate.managedObjectContext;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btninsert:(id)sender {
    
    _object =[NSEntityDescription insertNewObjectForEntityForName:@"Student" inManagedObjectContext:_context];
    
    [_object setValue:_txtid.text forKey:@"student_id"];
    [_object setValue:_txtfname.text forKey:@"f_name"];
    [_object setValue:_txtage.text forKey:@"age"];
    
    [_context save:nil];
    
}

- (IBAction)btnupdate:(id)sender {
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Student" inManagedObjectContext:_context];
    [fetchRequest setEntity:entity];
    
    // Specify criteria for filtering which objects to fetch
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"(student_id=%@)", _txtid.text];
    [fetchRequest setPredicate:predicate];
    
    // Specify how the fetched objects should be sorted
    NSError *error = nil;
    NSArray *fetchedObjects = [_context executeFetchRequest:fetchRequest error:&error];
    
    NSManagedObject *manage;
    
    if ([fetchedObjects count] ==0) {
        NSLog(@"not found");
    }
    else
    {
        manage = [fetchedObjects objectAtIndex:0];
        
        [manage setValue:_txtid.text forKey:@"student_id"];
        [manage setValue:_txtfname.text forKey:@"f_name"];
        [manage setValue:_txtage.text forKey:@"age"];
        
        [_context save:nil];
        
    }
}

- (IBAction)btndelete:(id)sender {
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Student" inManagedObjectContext:_context];
    [fetchRequest setEntity:entity];
    
    // Specify criteria for filtering which objects to fetch
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"(student_id=%@)", _txtid.text];
    [fetchRequest setPredicate:predicate];
    
    //NSManagedObject *manage;
    // Specify how the fetched objects should be sorted
    NSError *error = nil;
    NSArray *fetchedObjects = [_context executeFetchRequest:fetchRequest error:&error];
    
    if ([fetchedObjects count] ==0) {
        NSLog(@"not found");
    }
    else
    {
        for (NSManagedObject *obj in fetchedObjects)
        {
            [_context deleteObject:obj];
        }
        
        [_context save:nil];
        
    }
}

- (IBAction)btnfind:(id)sender {
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Student" inManagedObjectContext:_context];
    [fetchRequest setEntity:entity];
    
    // Specify criteria for filtering which objects to fetch
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"(student_id=%@)", _txtid.text];
    [fetchRequest setPredicate:predicate];
    
    // Specify how the fetched objects should be sorted
    NSError *error = nil;
    NSArray *fetchedObjects = [_context executeFetchRequest:fetchRequest error:&error];
    
    NSManagedObject *manage;
    
    if ([fetchedObjects count] ==0) {
        NSLog(@"not found");
    }
    else
    {
        manage = [fetchedObjects objectAtIndex:0];
        
        _txtid.text = [manage valueForKey:@"student_id"];
        _txtfname.text =[manage valueForKey:@"f_name"];
        _txtage.text =[manage valueForKey:@"age"];
        
    }    
}
@end
