//
//  JsonViewCellTableViewCell.m
//  JsonParsingDemo
//
//  Created by MACOS on 07/10/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import "JsonViewCellTableViewCell.h"

@implementation JsonViewCellTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
