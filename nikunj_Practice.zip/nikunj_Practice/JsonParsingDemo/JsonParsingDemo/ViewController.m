//
//  ViewController.m
//  JsonParsingDemo
//
//  Created by MACOS on 07/10/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import "ViewController.h"
#import "custcell.h"

@interface ViewController ()
{
    NSArray *globalary;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    NSURL *url=[NSURL URLWithString:@"http://api.androidhive.info/contacts/"];
    
    NSData *data=[NSData dataWithContentsOfURL:url];
    
    NSDictionary *dic=[NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];
     
    //NSLog(@"%@",[dic description]);
    
    globalary=[[NSArray alloc] init];
    globalary=[dic valueForKey:@"contacts"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger) numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [globalary count];
}

-(UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    custcell *cc=[tableView dequeueReusableCellWithIdentifier:@"cell1"];
    cc.val_id.text=[[globalary objectAtIndex:indexPath.row] valueForKey:@"id"];
    cc.val_name.text=[[globalary objectAtIndex:indexPath.row] valueForKey:@"name"];
    cc.val_email.text=[[globalary objectAtIndex:indexPath.row] valueForKey:@"email"];
    cc.val_address.text=[[globalary objectAtIndex:indexPath.row] valueForKey:@"address"];
    cc.val_gender.text=[[globalary objectAtIndex:indexPath.row] valueForKey:@"gender"];
    
    return cc;
}


@end
