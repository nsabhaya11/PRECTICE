//
//  custcell.h
//  JsonParsingDemo
//
//  Created by MACOS on 08/10/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface custcell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *val_id;
@property (weak, nonatomic) IBOutlet UILabel *val_name;
@property (weak, nonatomic) IBOutlet UILabel *val_email;
@property (weak, nonatomic) IBOutlet UILabel *val_address;
@property (weak, nonatomic) IBOutlet UILabel *val_gender;

@end
