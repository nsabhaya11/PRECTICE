//
//  custcell.m
//  JsonParsingDemo
//
//  Created by MACOS on 08/10/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import "custcell.h"

@implementation custcell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
