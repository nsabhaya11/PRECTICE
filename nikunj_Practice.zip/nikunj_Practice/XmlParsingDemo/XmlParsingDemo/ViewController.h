//
//  ViewController.h
//  XmlParsingDemo
//
//  Created by MACOS on 12/10/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController<NSXMLParserDelegate>


@end

