//
//  ViewController.m
//  XmlParsingDemo
//
//  Created by MACOS on 12/10/16.
//  Copyright © 2016 aarti. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    NSMutableArray *arr;
    NSMutableDictionary *dic;
    
    NSMutableString *str;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    // local file path
    NSString *path=[[NSBundle mainBundle] pathForResource:@"my" ofType:@"xml"];
    
   // NSURL *url=[NSURL URLWithString:path];
    
    NSData *data=[NSData dataWithContentsOfFile:path];
    NSXMLParser *parse=[[NSXMLParser alloc] initWithData:data];
    parse.delegate=self;
    [parse parse];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)parserDidStartDocument:(NSXMLParser *)parser
{
    arr=[[NSMutableArray alloc] init];
    
}

-(void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary<NSString *,NSString *> *)attributeDict
{
    if ([elementName isEqualToString:@"student"]) {
        dic=[[NSMutableDictionary alloc]init];
        
    }
}

-(void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    str =[[NSMutableString alloc]initWithString:string];
    
}

-(void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    if ([elementName isEqualToString:@"id"] || [elementName isEqualToString:@"name"]) {
        [dic setValue:str forKey:elementName];
    }
    else if([elementName isEqualToString:@"student"])
    {
        [arr addObject:dic];
    }
}

-(void)parserDidEndDocument:(NSXMLParser *)parser
{
    NSLog(@"%@",arr);
}

@end
