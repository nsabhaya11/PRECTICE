<?php
    $con=new mysqli("localhost","root","","Fruit_Guide");
   // $_POST
    $userid=$_POST['User_id'];
    $questiondesc=$_POST['Question_description'];
    $Nutritionid=$_POST['Nutrition_id'];
    //$ans=$_POST['Answer'];
    
    $qu="insert into Question_answer(User_id,Question_description,Nutrition_id)values('$userid','$questiondesc','$Nutritionid')";
    $con->Query($qu);
    echo "Success";
    
    ?>

