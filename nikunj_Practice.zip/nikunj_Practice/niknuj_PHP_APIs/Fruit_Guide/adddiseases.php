<?php
    $con=new mysqli("localhost","root","","Fruit_Guide");
    
    //$diseasesid=$_['Diseases_id'];
    $diseasesname=$_REQUEST['Diseases_name'];
    
    
    $qu="insert into Add_Diseases(Diseases_name)values('$diseasesname')";
    $con->Query($qu);
    echo "Success";
    
    
    
    
    ?>

