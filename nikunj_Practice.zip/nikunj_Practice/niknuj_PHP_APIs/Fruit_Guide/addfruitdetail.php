<?php
    $con=new mysqli("localhost","root","","Fruit_Guide");
   // $_POST
    $diseasesname=$_POST['Diseases_Name'];
    $fruitname=$_POST['Fruit_name'];
    $fruitdetail=$_POST['Fruit_detail'];
    $nutritionid=$_POST['Nutrition_id'];
    
    $qu="insert into Get_Fruitguide(Diseases_Name,Fruit_name,Fruit_detail,Nutrition_id)values('$diseasesname','$fruitname','$fruitdetail','$nutritionid')";
    $con->Query($qu);
    echo "Success";
    
    ?>

