<?php
$con=new mysqli("localhost","root","","Fruit_Guide");
        $Q1="select * from Get_Diseases";

        $pp=$con->Query($Q1);
        while ($ff=$pp->fetch_object())
        {
            $qq[]=$ff;
        }
        echo json_encode($qq);
    ?>

