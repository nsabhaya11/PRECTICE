<?php
	$con=new mysqli("localhost","root","","Fruit_guide");
    
    if(isset($_REQUEST["all"]))
    {
        $q = "SELECT * FROM 'nutrition_type'";
        $data = $con->query($q);
        while($dt=$data->fetch_object())
        {
            $rows[]=$dt;
        }
        echo json_encode($rows);
        echo $row;
    }


	
?>

