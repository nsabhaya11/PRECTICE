<?php
	$con=new mysqli("localhost","root","","prac");
	
	$nutritionid=$_POST['Nutrition_ID'];
	$nutritiontypeid=$_POST['Nutrition_type_id'];
	$nutritionname=$_POST['Nutrition_name'];
    $qulification=$_POST['Qulification'];
    $nutritionnameid=$_POST['Nutrition_name_id'];
    $mobile=$_POST['Mobile'];
    $address=$_POST['Address'];
    $password=$_POST['Password'];
    $status=$_POST['Status'];
    $experience=$_POST['Experience'];
    $image=$_POST['nutrition_image'];
	
	$qu="insert into Fruit_Guide(Nutrition_ID,Nutrition_type_id,Nutrition_name,Qulification,Nutrition_name_id,Mobile,Address,Password,Status,Experience,nutrition_image)values('$nutritionid','$nutritiontypeid','$nutritionname','$qulification','$nutritionnameid','$mobile','$address','$password','$status','$experience','$image')";
	$con->Query($qu);
	echo "Success";
	


	
?>

