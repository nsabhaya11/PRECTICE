<?php
    $con=new mysqli("localhost","root","","Fruit_Guide");
    
    $nutritionid=$_POST['Nutrition_ID'];
    $nutritiontypeid=$_POST['Nutrition_type_id'];
    $nutritionname=$_POST['Nutrition_name'];
    $qulification=$_POST['Qulification'];
    $mobile=$_POST['Mobile'];
    $address=$_POST['Address'];
    $password=$_POST['Password'];
    $status=$_POST['Status'];
    $experience=$_POST['Experience'];
    $image=$_POST['nutrition_image'];
    
    $qu="insert into Nutrition_Reg(Nutrition_ID,Nutrition_type_id,Nutrition_name,Qulification,Mobile,Address,Password,Status,Experience,nutrition_image)values('$nutritionid','$nutritiontypeid','$nutritionname','$qulification','$mobile','$address','$password','$status','$experience','$image')";
    $con->Query($qu);
    echo "Success";
    
    
    
    
    ?>

