<?php
$con=new mysqli("localhost","root","","Fruit_Guide");    
if (isset($_REQUEST['Nutrition_name'])) 
    {
        $nutritionname=$_REQUEST['Nutrition_name'];
        $password=$_REQUEST['Password'];
        $Q1="select Nutrition_ID,Nutrition_name,Password from Nutrition_Reg where Nutrition_name='$nutritionname' and Password='$password'";

        $pp=$con->Query($Q1);
        while ($ff=$pp->fetch_object()) {
            $qq[]=$ff;
        }
        echo json_encode($qq);
    }
        else{
        /*{
$Query='select * from Nutrition_Reg';

$pp=$con->Query($Query);
while ($ff->cubrid_fetch_object()) {
    $qq[]=$ff;
}*
echo json_encode($qq);
        }*/
        echo 'Invalid Username';
    
}

    
    
    
    
    ?>

