<?php
$con=new mysqli("localhost","root","","Fruit_Guide");    
if (isset($_REQUEST['User_Name'])) 
    {
        $usernname=$_REQUEST['User_Name'];
        $pass=$_REQUEST['password'];
        $Q1="select User_Name,password,User_ID from userreg where User_Name='$usernname' and password='$pass'";

        $pp=$con->Query($Q1);
        while ($ff=$pp->fetch_object()) {
            $qq[]=$ff;
        }
        echo json_encode($qq);
    }
        else{
        /*{
$Query='select * from Nutrition_Reg';

$pp=$con->Query($Query);
while ($ff->cubrid_fetch_object()) {
    $qq[]=$ff;
}*
echo json_encode($qq);
        }*/
        echo 'Invalid Username';
    
}

    
    
    
    
    ?>

