<?php
    $con=new mysqli("localhost","root","","Fruit_Guide");
    
    $userid=$_POST['User_ID'];
    $password=$_POST['password'];
    $username=$_POST['User_Name'];
    $emailid=$_POST['Email_ID'];
    $mobile=$_POST['Mobile'];
    $address=$_POST['Address'];
    $diseasestype=$_POST['Diseases_Type'];
    $image=$_POST['user_image'];
    
    $qu="insert into userreg(User_ID,password,User_Name,Email_ID,Mobile,Address,Diseases_Type,user_image)values('$userid','$password','$username','$emailid','$mobile','$address','$diseasestype','$image')";
    $con->Query($qu);
    echo "Success";
    
    
    
    
    ?>

