<?php
    $id = $_REQUEST["nid"];
$con=new mysqli("localhost","root","","Fruit_Guide");
    //$id = $_REQUEST["nid"];
        $Q1="select * from Nutrition_Reg where Nutrition_ID='$id'";

        $pp=$con->Query($Q1);
        while ($ff=$pp->fetch_object())
        {
            $qq[]=$ff;
        }
        echo json_encode($qq);
    ?>

