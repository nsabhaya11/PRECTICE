<?php
    $id = $_REQUEST["Nutrition_ID"];
$con=new mysqli("localhost","root","","Fruit_Guide");
    //$id = $_REQUEST["nid"];
        $Q1="select userreg.User_Name,Question_answer.Question_description from Question_answer,userreg where Question_answer.User_id= userreg.User_id and Question_answer.Nutrition_ID='$id'";

        $pp=$con->Query($Q1);
        while ($ff=$pp->fetch_object())
        {
            $qq[]=$ff;
        }
        echo json_encode($qq);
    ?>

