<?php
    $id = $_POST["User_id"];
$con=new mysqli("localhost","root","","Fruit_Guide");
    //$id = $_REQUEST["nid"];
        $Q1="select Nutrition_Reg.Nutrition_name,Question_answer.Question_description from Question_answer,Nutrition_Reg where Question_answer.Nutrition_id= Nutrition_Reg.Nutrition_ID and Question_answer.User_id='$id'";

        $pp=$con->Query($Q1);
        while ($ff=$pp->fetch_object())
        {
            $qq[]=$ff;
        }
        echo json_encode($qq);
    ?>

