<?php
    

    $con=new mysqli("localhost","root","","school");
    
    if(isset($_REQUEST['first']))
    {
        
        $id=$_REQUEST['first'];
        
        
        $qu="delete from detail where id='$id'";
        $con->query($qu);
        
        //echo "<script>alert('Operation completed successfully')</script>";
        echo "success";
    }
    

    
    
?>
