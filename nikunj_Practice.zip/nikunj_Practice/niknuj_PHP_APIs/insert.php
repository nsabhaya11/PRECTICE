<?php
    $con=new mysqli("localhost","root","","school");
    
    if(isset($_REQUEST['first']))
    {
         $nm=$_REQUEST['first'];
        $eml=$_REQUEST['second'];
		 $gdr=$_REQUEST['third'];
				
        
       $qu="insert into detail(name,email,gender)values('$nm','$eml','$gdr')";
        echo $qu;
        $con->query($qu);
        
        
        echo "success";
    }
    

    
    
    
?>
