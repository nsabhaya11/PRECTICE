<?php
    $con=new mysqli("localhost","root","","Student_DB");

   
        $fname=$_REQUEST['f_name'];
        $age=$_REQUEST['age'];
        $qry="insert into student (f_name,age) values ('$fname','$age')";
        $con->query($qry);
        echo "Success";

?>
