<?php
    $con=new mysqli("localhost","root","","school");
    
    if(isset($_REQUEST['first']))
    {
         $id=$_REQUEST['first'];
        
        
       $qu="select * from detail where id=$id";
        
        $pp=$con->query($qu);
        
        while($ff=$pp->fetch_object())
        {
            $qq[]=$ff;
        }
        echo json_encode($qq);
    }
    

    
    
    
?>
