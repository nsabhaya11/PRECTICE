<?php
    

    $con=new mysqli("localhost","root","","school");
    
    if(isset($_REQUEST['first']))
    {
        
        $nm=$_REQUEST['first'];
        $eml=$_REQUEST['second'];
        $gdr=$_REQUEST['third'];
        $id=$_REQUEST['forth'];
        
        
        
        $qu="update detail set name='$nm',email='$eml',gender='$gdr' where id='$id'";
        $con->query($qu);
        
        //echo "<script>alert('Operation completed successfully')</script>";
        echo "success";
    }
    

    
    
?>
